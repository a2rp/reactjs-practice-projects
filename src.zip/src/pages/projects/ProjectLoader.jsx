// components/projects/ProjectLoader.jsx
import React, { lazy } from "react";

export const loadProjectComponent = (name) => {
    return lazy(() =>
        import(`../projects/${name}/index.jsx`).catch((err) => {
            console.error(`Failed to load ${name}:`, err);
            return { default: () => <h2 style={{ color: 'red' }}>Component Load Error</h2> };
        })
    );
};
