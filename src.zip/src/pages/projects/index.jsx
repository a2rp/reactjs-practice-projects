// import React, { Suspense } from 'react';
// import { useParams } from 'react-router-dom';
// import { CircularProgress, Box } from '@mui/material';
// import { lazyComponentMap } from '../../components/lazyComponents';

// const Projects = () => {
//     const { name } = useParams();
//     // console.log(name, "name");

//     const Component = lazyComponentMap[name];

//     return (
//         <Suspense
//             fallback={
//                 <Box sx={{ width: '100%', height: '60vh', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
//                     <CircularProgress />
//                 </Box>
//             }
//         >
//             {Component ? <Component /> : <div style={{ color: '#fff' }}>Component "{name}" not found.</div>}
//         </Suspense>
//     );
// };

// export default Projects;


// pages/projects/index.jsx
import React, { Suspense } from "react";
import { useParams } from "react-router-dom";
import { CircularProgress, Box } from "@mui/material";
import { loadProjectComponent } from "./ProjectLoader";
import { projectList } from "../../data/projectList";

const Projects = () => {
    const { uri } = useParams();

    const project = projectList.find((p) => p.uri === uri);
    const Component = project ? loadProjectComponent(project.name) : null;

    if (!project || !Component) {
        return <h2 style={{ color: "red", textAlign: "center" }}>Project Not Found</h2>;
    }

    return (
        <Suspense fallback={
            <Box sx={{ display: "flex", justifyContent: "center", mt: 5 }}>
                <CircularProgress />
            </Box>
        }>
            <Component />
        </Suspense>
    );
};

export default Projects;
