const TypingKeyboard = () => {
    return (<>
        <h1>typingKeyboard</h1>
    </>);
}

export default TypingKeyboard