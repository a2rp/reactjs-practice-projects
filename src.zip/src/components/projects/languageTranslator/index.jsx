import React from 'react'

const LanguageTranslator = () => {
    return (
        <div>
            Language Translator
        </div>
    )
}

export default LanguageTranslator
